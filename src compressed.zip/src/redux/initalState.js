export default {
	results: [],
	apiCallsInProgress: 0,
	page: 0,
};
